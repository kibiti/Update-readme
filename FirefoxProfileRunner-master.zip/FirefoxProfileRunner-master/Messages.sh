#! /usr/bin/env bash
$XGETTEXT src/*.cpp -o $podir/plasma_runner_org.kde.firefoxprofilerunner.pot
